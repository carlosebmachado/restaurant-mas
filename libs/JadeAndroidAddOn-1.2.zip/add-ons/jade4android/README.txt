jade4android add on readme file

In order to build the add-on customize the build.properties file then simply go to the home dir of the project and type ant.
In order to build the .apk installation file of the DummyAgent example go to the home dir of the project and type ant demo.

For details see the guide in the <home>/doc dir

